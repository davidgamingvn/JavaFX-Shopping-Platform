module Final.Project.JavaFX {
    requires javafx.graphics;
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.swt;
    requires javafx.base;
    requires javafx.swing;
    requires java.sql;
    requires org.postgresql.jdbc;
    requires com.jfoenix;

    opens sample;
}